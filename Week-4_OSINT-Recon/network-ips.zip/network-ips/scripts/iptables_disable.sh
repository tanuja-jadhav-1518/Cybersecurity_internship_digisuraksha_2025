#!/usr/bin/env bash
set -euo pipefail
echo "[*] Flushing NFQUEUE rules from INPUT ... requires root"
iptables -D INPUT -p icmp -j NFQUEUE --queue-num 3 || true
iptables -D INPUT -p tcp -j NFQUEUE --queue-num 3 || true
iptables -D INPUT -p udp -j NFQUEUE --queue-num 3 || true
