#!/usr/bin/env bash
set -euo pipefail
QUEUE=${1:-3}
echo "[*] Redirecting INPUT to NFQUEUE $QUEUE (icmp,tcp,udp) ... requires root"
iptables -I INPUT -p icmp -j NFQUEUE --queue-num $QUEUE
iptables -I INPUT -p tcp -j NFQUEUE --queue-num $QUEUE
iptables -I INPUT -p udp -j NFQUEUE --queue-num $QUEUE
iptables -L -n | head -n 20
