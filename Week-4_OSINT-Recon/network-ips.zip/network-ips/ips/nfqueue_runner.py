import os, json, time
from netfilterqueue import NetfilterQueue
from scapy.all import IP, IPv6
from .detector import IPSDetector, packet_meta_from_scapy, write_alert
from .detector import DetectorConfig

def run_nfqueue(cfg: DetectorConfig, queue_num: int = 3, flush_log: bool = False):
    det = IPSDetector(cfg)
    if flush_log and os.path.exists("logs/alerts.jsonl"):
        with open("logs/alerts.jsonl", "w"): pass

    def on_packet(pkt):
        try:
            raw = pkt.get_payload()
            # scapy can parse both v4 and v6 when first byte indicates version
            # Attempt IP first; if fails, try IPv6
            sp = None
            try:
                sp = IP(raw)
            except Exception:
                sp = IPv6(raw)
            meta = packet_meta_from_scapy(sp)
            if not meta:
                pkt.accept(); return
            decision = det.decide(meta)
            if decision["action"] == "DROP":
                write_alert(decision)
                pkt.drop()
            else:
                pkt.accept()
        except Exception as e:
            # Fail open to avoid breaking connectivity
            pkt.accept()

    nfq = NetfilterQueue()
    nfq.bind(queue_num, on_packet)
    try:
        print(f"[*] Bound to NFQUEUE {queue_num}. Press Ctrl+C to stop.")
        nfq.run()
    except KeyboardInterrupt:
        print("[*] Stopping...")
    finally:
        nfq.unbind()
